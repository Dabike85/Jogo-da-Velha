public class Perceptron {
   public List<Entrada> Entradas {get; set;}
   public double Saida {get; set;}
   public double TaxaAprendizado {get; set;}
   
   public perceptron () {
      
}
   public double Somatorio() {
      double valorSomatorio = 0;
      foreach(var item in Entradas)
         {
            valorSomatorio += item.Peso * item.Valor;
         }
         return valorSomatorio;

}
   public bool FuncaoDeGrau(double somatorio) {
      return somatorio >=0;
}

}