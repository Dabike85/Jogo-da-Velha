public class Entradas {
   public double Valor {get; set;}
   public double Peso {get; set;}

}
