﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JogoDaVelhaIA.Enum
{
	public enum EnumTipoPeca
	{
		X,
		O,
		VAZIO
	}
}
